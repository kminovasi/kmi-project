<section class="my-5">
    @livewire('info-inovation')
</section>
