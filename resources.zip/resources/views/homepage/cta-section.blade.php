<section class="bg-light py-5">
    <div class="container">
        <div class="shadow rounded text-center text-white p-5"
        style="  background: rgb(195, 34, 34);
            background: linear-gradient(
                120deg,
                rgba(195, 34, 34, 1) 25%,
                rgba(255, 143, 77, 1) 100%
            );">
        <h2 class="display-5 fw-bold text-white mt-3">
            Jadilah bagian dari inovasi besar
        </h2>
        <p class="lead text-white mt-3">
            Bergabunglah sekarang dan jadilah inovator terbaik tahun ini.
        </p>
        <a href="/dashboard" class="btn btn-warning text-black text-decoration-none mt-3 mb-3 shadow">Daftarkan Tim
            Anda</a>
    </div>
    </div>
</section>
