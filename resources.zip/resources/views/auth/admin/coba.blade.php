<html>
    <h1>WELCOME {{ auth('admin')->user() }} </h1>
</html>