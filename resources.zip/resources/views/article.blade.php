@extends('layouts.guest')
@section('title', 'Berita')

@section('content')



@endsection
