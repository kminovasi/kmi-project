<div class="accordion accordion-flush" id="{{ $id }}">
    {{ $slot }}
</div>
