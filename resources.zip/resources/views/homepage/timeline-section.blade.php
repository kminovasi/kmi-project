
<section class="container py-5">
    <header class="mb-4">
        <h2 class="display-5 fw-bold text-danger mt-3">Timeline Event</h2>
        <p class="lead text-muted mt-3">
            Catat tanggal-tanggal penting dan jangan lewatkan setiap momen!
        </p>
    </header>

    @livewire('timeline-event')

</section>
