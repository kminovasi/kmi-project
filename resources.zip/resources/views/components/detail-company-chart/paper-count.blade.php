<div class="chart-container">
    <h5 class="chart-title">Jumlah Makalah Innovasi <span class="company-name">{{ $companyName }}</span> setiap tahun
    </h5>
    <canvas id="paperCountChart" data-chart="{{ $chartData }}" data-company="{{ $companyName }}"></canvas>
</div>
