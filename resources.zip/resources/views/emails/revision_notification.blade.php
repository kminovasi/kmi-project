<!DOCTYPE html>
<html>

<head>
    <title>Revisi Makalah</title>
</head>

<body>
    <p>Halo,</p>
    <p>Tim <strong>{{ $team->team_name }}</strong> telah berhasil melakukan revisi makalah.</p>
    <p>Silakan cek detailnya pada sistem.</p>
    <p>Terima kasih.</p>
</body>

</html>
