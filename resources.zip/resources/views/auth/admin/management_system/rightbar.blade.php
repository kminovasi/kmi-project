<div class="col-lg-3">
    <div class="nav-sticky">
        <div class="card">
            <div class="card-header text-white bg-primary">
                SUB MENU
            </div>
            <div class="card-body">

                <ul class="nav flex-column" id="stickyNav">
                    <li class="nav-item"><a class="nav-link" href="#basic">Role</a></li>
                    <li class="nav-item"><a class="nav-link" href="#basic">Assign Role</a></li>
                    <li class="nav-item"><a class="nav-link" href="#basic">Assign Event</a></li>
                    <li class="nav-item"><a class="nav-link" href="#basic">Assessment</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>